


<div class="footer">
    


<div class="col-lg-4">
<h3>#TheDress </h3>


<img src="img/dress-twitter.jpg" alt="" width="100%" height="100%">


</div>
<div class="col-lg-4">
<h3>All the Fuzz(Explained)</h3>
<iframe width="100%" height="120%" src="https://www.youtube.com/embed/_nr1TN9xOI0" frameborder="0" allowfullscreen></iframe>


</div>
<div class="col-lg-4">

<h3>The story behind #TheDress</h3>
<p>Here's #TheDress which broke the internet and it all started when <em>swiked</em> uploaded this photo on her tumblr page and then buzzfeed published the story. The internet is ablaze about the dress and we thought we'll conduct a poll on how many were <em>"<strong>deceived</strong>"</em> by the colour of the dress. Arent you a bit keen about how other people in the world saw it? LET'S FIND OUT!</p>

</div>


</div>
<!-- container ends below this line. -->

<p class="center col-lg-12">
	
PS: This is a result of 13 hours of sloppy coding. Made with <i class="glyphicon glyphicon-heart"></i> anyways.
</p>

</div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery-2.1.3.min.js"></script>
        <script src="js/jquery-2.1.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/main.js"></script>

    </body>
</html>

